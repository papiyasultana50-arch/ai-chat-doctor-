
export enum Role {
  USER = 'user',
  MODEL = 'model',
  SYSTEM = 'system'
}

export type ThemeType = 'classic' | 'nature' | 'night' | 'rose';

export interface Message {
  role: Role;
  content: string;
  timestamp: Date;
}

export interface ChatSession {
  id: string;
  title: string;
  messages: Message[];
  lastModified: Date;
}

export interface HealthTip {
  title: string;
  description: string;
  icon: string;
}
