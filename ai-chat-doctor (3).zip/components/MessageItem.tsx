
import React from 'react';
import { Message, Role, ThemeType } from '../types';

interface MessageItemProps {
  message: Message;
  theme?: ThemeType;
}

const MessageItem: React.FC<MessageItemProps> = ({ message, theme = 'classic' }) => {
  const isUser = message.role === Role.USER;

  const userBubbleColors = {
    classic: 'bg-blue-600 shadow-blue-100',
    nature: 'bg-emerald-600 shadow-emerald-100',
    night: 'bg-indigo-600 shadow-indigo-900/20',
    rose: 'bg-rose-500 shadow-rose-100'
  };

  const aiBubbleColors = {
    classic: 'bg-white border-slate-200 text-slate-800 shadow-slate-100',
    nature: 'bg-white border-emerald-100 text-emerald-900 shadow-emerald-100/50',
    night: 'bg-slate-800 border-slate-700 text-slate-100 shadow-black/20',
    rose: 'bg-white border-rose-100 text-rose-900 shadow-rose-100/50'
  };

  const formatContent = (content: string) => {
    return content.split('\n').map((line, i) => {
      const trimmed = line.trim();
      if (trimmed.startsWith('*') || trimmed.startsWith('-')) {
        return <li key={i} className="ml-4 list-disc mb-1">{trimmed.substring(1).trim()}</li>;
      }
      if (trimmed.startsWith('#')) {
        return <h4 key={i} className={`font-bold mt-2 mb-1 ${theme === 'night' ? 'text-indigo-400' : 'text-slate-800'}`}>{trimmed.replace(/#/g, '').trim()}</h4>;
      }
      return <p key={i} className="mb-2 leading-relaxed">{trimmed}</p>;
    });
  };

  return (
    <div className={`flex w-full mb-6 ${isUser ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
      <div className={`flex max-w-[85%] md:max-w-[75%] ${isUser ? 'flex-row-reverse' : 'flex-row'} items-start gap-3`}>
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-bold shadow-md transition-all duration-500 ${
          isUser 
            ? 'bg-slate-200 text-slate-600' 
            : `${userBubbleColors[theme]} text-white`
        }`}>
          {isUser ? 'ME' : 'DR'}
        </div>

        <div className={`rounded-2xl px-4 py-3 shadow-sm border transition-all duration-500 ${
          isUser 
            ? `${userBubbleColors[theme]} text-white border-transparent rounded-tr-none` 
            : `${aiBubbleColors[theme]} rounded-tl-none`
        }`}>
          <div className="message-content text-sm md:text-base">
            {formatContent(message.content)}
          </div>
          <div className={`text-[10px] mt-1 opacity-60 font-medium ${isUser ? 'text-blue-50' : (theme === 'night' ? 'text-slate-500' : 'text-slate-400')}`}>
            {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessageItem;
