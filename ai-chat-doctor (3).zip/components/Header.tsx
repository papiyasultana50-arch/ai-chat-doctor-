
import React, { useState } from 'react';
import { ThemeType } from '../types';

interface HeaderProps {
  userName?: string;
  onNewChat?: () => void;
  onDownloadAPK?: () => void;
  isOnline?: boolean;
  theme?: ThemeType;
  onThemeChange?: (theme: ThemeType) => void;
}

const Header: React.FC<HeaderProps> = ({ 
  userName, 
  onNewChat, 
  onDownloadAPK, 
  isOnline = true,
  theme = 'classic',
  onThemeChange 
}) => {
  const [showThemes, setShowThemes] = useState(false);

  const themes: {id: ThemeType, color: string, name: string}[] = [
    { id: 'classic', color: 'bg-blue-600', name: 'Classic' },
    { id: 'nature', color: 'bg-emerald-600', name: 'Nature' },
    { id: 'night', color: 'bg-slate-900', name: 'Night' },
    { id: 'rose', color: 'bg-rose-500', name: 'Care' },
  ];

  const currentTheme = themes.find(t => t.id === theme) || themes[0];

  return (
    <header className={`${theme === 'night' ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'} border-b px-4 md:px-6 py-4 flex items-center justify-between sticky top-0 z-20 shadow-sm transition-colors duration-500`}>
      <div className="flex items-center gap-2 md:gap-3">
        <div className={`w-9 h-9 md:w-10 md:h-10 ${currentTheme.color} rounded-lg flex items-center justify-center shadow-lg relative transition-colors duration-500`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 md:h-6 md:w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 01-.586 1.414l-2.828 2.828A2 2 0 0110.172 15H9.828a2 2 0 01-1.414-.586l-2.828-2.828A2 2 0 015 10.172V5L4 4z" />
          </svg>
          <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full border-2 ${theme === 'night' ? 'border-slate-900' : 'border-white'} ${isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>
        </div>
        <div>
          <h1 className={`text-lg md:text-xl font-bold leading-tight ${theme === 'night' ? 'text-white' : 'text-slate-800'}`}>AI Doctor</h1>
          <p className={`hidden xs:block text-[10px] md:text-xs font-medium flex items-center gap-1 ${theme === 'night' ? 'text-slate-400' : 'text-blue-600'}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${isOnline ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
            {isOnline ? 'অনলাইন' : 'অফলাইন'}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 md:gap-4">
        {/* Theme Switcher */}
        <div className="relative">
          <button 
            onClick={() => setShowThemes(!showThemes)}
            className={`p-2 rounded-lg transition-colors ${theme === 'night' ? 'text-slate-400 hover:bg-slate-800' : 'text-slate-500 hover:bg-slate-100'}`}
            title="থিম পরিবর্তন করুন"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21a4 4 0 01-4-4V5a2 2 0 012-2h4a2 2 0 012 2v12a4 4 0 01-4 4zm0 0h12a2 2 0 002-2v-4a2 2 0 00-2-2h-2.343M11 7.343l1.172-1.172a4 4 0 115.656 5.656l-1.172 1.172" />
            </svg>
          </button>
          
          {showThemes && (
            <>
              <div className="fixed inset-0 z-10" onClick={() => setShowThemes(false)}></div>
              <div className={`absolute right-0 mt-2 w-48 rounded-2xl shadow-xl z-20 p-2 border animate-in fade-in slide-in-from-top-2 ${theme === 'night' ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-100'}`}>
                <p className={`text-[10px] font-bold uppercase tracking-widest px-3 py-1.5 ${theme === 'night' ? 'text-slate-500' : 'text-slate-400'}`}>Healing Themes</p>
                {themes.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => {
                      onThemeChange?.(t.id);
                      setShowThemes(false);
                    }}
                    className={`w-full flex items-center gap-3 p-2 rounded-xl transition-all ${theme === t.id ? (theme === 'night' ? 'bg-slate-700' : 'bg-slate-50') : 'hover:bg-slate-100/50'}`}
                  >
                    <div className={`w-4 h-4 rounded-full ${t.color}`}></div>
                    <span className={`text-xs font-semibold ${theme === 'night' ? 'text-slate-200' : 'text-slate-700'}`}>{t.name}</span>
                    {theme === t.id && <svg className="h-4 w-4 ml-auto text-blue-500" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>}
                  </button>
                ))}
              </div>
            </>
          )}
        </div>

        {onDownloadAPK && (
          <button 
            onClick={onDownloadAPK}
            className={`flex items-center gap-2 px-3 py-1.5 ${currentTheme.color} text-white rounded-xl text-xs font-bold hover:brightness-110 transition-all shadow-md`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M9 19l3 3m0 0l3-3m-3 3V10" />
            </svg>
            <span className="hidden sm:inline">ডাউনলোড</span>
          </button>
        )}
        
        {onNewChat && (
          <button 
            onClick={onNewChat}
            className={`p-2 rounded-lg transition-all ${theme === 'night' ? 'text-slate-400 hover:bg-slate-800' : 'text-slate-500 hover:bg-slate-100'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
          </button>
        )}
      </div>
    </header>
  );
};

export default Header;
