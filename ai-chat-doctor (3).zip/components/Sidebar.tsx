
import React from 'react';
import { HEALTH_TIPS } from '../constants';
import { ChatSession, ThemeType } from '../types';

interface SidebarProps {
  theme?: ThemeType;
  onDownloadAPK?: () => void;
  onNewChat?: () => void;
  onClearAll?: () => void;
  sessions?: ChatSession[];
  currentSessionId?: string;
  onSwitchSession?: (id: string) => void;
  onDeleteSession?: (id: string, e: React.MouseEvent) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ 
  theme = 'classic',
  onDownloadAPK, 
  onNewChat,
  onClearAll,
  sessions = [],
  currentSessionId,
  onSwitchSession,
  onDeleteSession
}) => {
  const accentColor = {
    classic: 'bg-blue-600 hover:bg-blue-700',
    nature: 'bg-emerald-600 hover:bg-emerald-700',
    night: 'bg-indigo-500 hover:bg-indigo-600',
    rose: 'bg-rose-500 hover:bg-rose-600'
  }[theme];

  const sidebarBg = theme === 'night' ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200';
  const textColor = theme === 'night' ? 'text-slate-100' : 'text-slate-800';
  const secondaryText = theme === 'night' ? 'text-slate-500' : 'text-slate-400';

  return (
    <aside className={`hidden lg:flex flex-col w-80 ${sidebarBg} border-l overflow-hidden transition-colors duration-500`}>
      <div className="p-6 space-y-6 overflow-y-auto flex-1 custom-scrollbar">
        {/* New Chat Button */}
        <section>
          <button
            onClick={onNewChat}
            className={`w-full flex items-center justify-center gap-2 py-3.5 ${accentColor} text-white rounded-2xl font-bold transition-all shadow-lg active:scale-[0.98]`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            নতুন চ্যাট
          </button>
        </section>

        {/* Sessions List */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h3 className={`text-xs font-bold uppercase tracking-widest ${secondaryText}`}>সাম্প্রতিক চ্যাট</h3>
            {sessions.length > 1 && (
              <button onClick={onClearAll} className="text-[10px] text-red-500 hover:text-red-700 font-bold transition-colors">সব মুছুন</button>
            )}
          </div>
          
          <div className="space-y-1.5">
            {sessions.length > 0 ? (
              sessions.map((session) => (
                <div
                  key={session.id}
                  onClick={() => onSwitchSession?.(session.id)}
                  className={`group flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all border ${
                    currentSessionId === session.id
                      ? (theme === 'night' ? 'bg-slate-800 border-indigo-500/30 text-indigo-400' : 'bg-blue-50 border-blue-200 text-blue-700')
                      : `bg-transparent border-transparent ${textColor} hover:${theme === 'night' ? 'bg-slate-800/50' : 'bg-slate-50'}`
                  }`}
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 flex-shrink-0 opacity-70" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                    </svg>
                    <span className="text-xs font-semibold truncate">{session.title}</span>
                  </div>
                  <button onClick={(e) => onDeleteSession?.(session.id, e)} className="p-1 text-slate-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-all">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  </button>
                </div>
              ))
            ) : (
              <p className={`text-[10px] italic text-center py-4 ${secondaryText}`}>কোনো হিস্ট্রি নেই</p>
            )}
          </div>
        </section>

        {/* APK Card */}
        <section className={`p-5 rounded-2xl text-white shadow-xl relative overflow-hidden transition-all duration-500 ${
          {
            classic: 'bg-gradient-to-br from-blue-600 to-indigo-700',
            nature: 'bg-gradient-to-br from-emerald-600 to-teal-700',
            night: 'bg-gradient-to-br from-slate-800 to-indigo-950',
            rose: 'bg-gradient-to-br from-rose-500 to-pink-600'
          }[theme]
        }`}>
          <div className="relative z-10">
            <h4 className="font-bold text-sm mb-1">অ্যান্ড্রয়েড অ্যাপ</h4>
            <p className="text-[10px] opacity-80 mb-4 leading-relaxed">সহজ ব্যবহারের জন্য আমাদের মোবাইল অ্যাপটি ডাউনলোড করুন।</p>
            <button 
              onClick={onDownloadAPK}
              className="w-full py-2.5 bg-white/20 backdrop-blur-md text-white rounded-xl text-xs font-bold hover:bg-white/30 transition-all active:scale-95 flex items-center justify-center gap-2"
            >
              ডাউনলোড করুন (APK)
            </button>
          </div>
          <div className="absolute -right-4 -bottom-4 opacity-10">
            <svg className="w-24 h-24" fill="currentColor" viewBox="0 0 24 24"><path d="M17.523 15.3414L20.355 20.2464C20.505 20.5014 20.415 20.8244 20.16 20.9744C19.905 21.1244 19.582 21.0344 19.432 20.7794L16.547 15.7814C15.141 16.5524 13.585 17.0004 12 17.0004C10.415 17.0004 8.859 16.5524 7.453 15.7814L4.568 20.7794C4.418 21.0344 4.095 21.1244 3.84 20.9744C3.585 20.8244 3.495 20.5014 3.645 20.2464L6.477 15.3414C3.805 13.7914 2 10.8914 2 7.60041C2 7.04841 2.448 6.60041 3 6.60041H21C21.552 6.60041 22 7.04841 22 7.60041C22 10.8914 20.195 13.7914 17.523 15.3414Z"/></svg>
          </div>
        </section>
      </div>

      <div className={`p-6 border-t ${theme === 'night' ? 'border-slate-800 bg-slate-900/50' : 'border-slate-100 bg-slate-50/50'}`}>
        <div className={`p-3 rounded-xl border ${theme === 'night' ? 'bg-red-950/20 border-red-900/30' : 'bg-red-50 border-red-100'}`}>
          <h4 className={`font-bold text-xs mb-1 flex items-center gap-1 ${theme === 'night' ? 'text-red-400' : 'text-red-900'}`}>⚠️ জরুরি?</h4>
          <a href="tel:999" className="block w-full text-center py-2 bg-red-600 text-white rounded-lg text-xs font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-500/20">কল করুন ৯৯৯</a>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
