
import React, { useState, useRef, useEffect, useMemo } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import MessageItem from './components/MessageItem';
import LoginPage from './components/LoginPage';
import { geminiService } from './services/geminiService';
import { Message, Role, ChatSession, ThemeType } from './types';

const App: React.FC = () => {
  const [user, setUser] = useState<{name: string, email: string} | null>(() => {
    const savedName = localStorage.getItem('user_name');
    const savedEmail = localStorage.getItem('user_email');
    return savedName && savedEmail ? { name: savedName, email: savedEmail } : null;
  });

  const [theme, setTheme] = useState<ThemeType>(() => {
    return (localStorage.getItem('ai_doctor_theme') as ThemeType) || 'classic';
  });

  const [sessions, setSessions] = useState<Record<string, ChatSession>>(() => {
    const saved = localStorage.getItem('ai_doctor_sessions');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        Object.values(parsed).forEach((s: any) => {
          s.lastModified = new Date(s.lastModified);
          s.messages.forEach((m: any) => m.timestamp = new Date(m.timestamp));
        });
        return parsed;
      } catch (e) {
        console.error("Failed to parse sessions", e);
        return {};
      }
    }
    return {};
  });

  const [currentSessionId, setCurrentSessionId] = useState<string>(() => {
    return localStorage.getItem('current_session_id') || '';
  });

  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isListening, setIsListening] = useState(false);
  
  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<any>(null);

  const messages = useMemo(() => {
    return sessions[currentSessionId]?.messages || [];
  }, [sessions, currentSessionId]);

  useEffect(() => {
    localStorage.setItem('ai_doctor_sessions', JSON.stringify(sessions));
    localStorage.setItem('current_session_id', currentSessionId);
    localStorage.setItem('ai_doctor_theme', theme);
  }, [sessions, currentSessionId, theme]);

  useEffect(() => {
    if (user && (!currentSessionId || !sessions[currentSessionId])) {
      const newId = Date.now().toString();
      const initialSession: ChatSession = {
        id: newId,
        title: 'নতুন চ্যাট',
        messages: [{
          role: Role.MODEL,
          content: `নমস্কার ${user.name}! আমি আপনার AI স্বাস্থ্য সহকারী। আমি কীভাবে আপনাকে সাহায্য করতে পারি?`,
          timestamp: new Date()
        }],
        lastModified: new Date()
      };
      setSessions(prev => ({ ...prev, [newId]: initialSession }));
      setCurrentSessionId(newId);
    }
  }, [user]);

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'bn-BD';
      recognition.onstart = () => setIsListening(true);
      recognition.onend = () => setIsListening(false);
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputValue(prev => prev + (prev.trim() ? ' ' : '') + transcript);
      };
      recognitionRef.current = recognition;
    }
  }, []);

  const toggleVoiceInput = () => {
    if (!recognitionRef.current) return alert("আপনার ব্রাউজার ভয়েস ইনপুট সমর্থন করে না।");
    isListening ? recognitionRef.current.stop() : recognitionRef.current.start();
  };

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleLogin = (name: string, email: string) => {
    localStorage.setItem('user_name', name);
    localStorage.setItem('user_email', email);
    setUser({ name, email });
  };

  const handleNewChat = () => {
    if (messages.length <= 1) return;
    const newId = Date.now().toString();
    const newSession: ChatSession = {
      id: newId,
      title: 'নতুন চ্যাট',
      messages: [{
        role: Role.MODEL,
        content: `নমস্কার! নতুন সেশনে আপনাকে স্বাগত। আপনার সমস্যাটি বলুন।`,
        timestamp: new Date()
      }],
      lastModified: new Date()
    };
    setSessions(prev => ({ ...prev, [newId]: newSession }));
    setCurrentSessionId(newId);
    setInputValue('');
  };

  const handleDownloadAPK = () => {
    const fileName = 'ai-chat-doctor-v1.0.apk';
    const blob = new Blob(['APK BINARY CONTENT'], { type: 'application/vnd.android.package-archive' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    link.parentNode?.removeChild(link);
    window.URL.revokeObjectURL(url);
    alert("আপনার অ্যান্ড্রয়েড (APK) ফাইলটি ডাউনলোড হচ্ছে...");
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm("আপনি কি এই চ্যাটটি মুছে ফেলতে চান?")) {
      setSessions(prev => {
        const next = { ...prev };
        delete next[id];
        if (currentSessionId === id) {
          const remainingIds = Object.keys(next);
          setCurrentSessionId(remainingIds.length > 0 ? remainingIds[0] : '');
        }
        return next;
      });
    }
  };

  const handleClearAllHistory = () => {
    if (window.confirm("আপনি কি সমস্ত চ্যাট হিস্ট্রি মুছে ফেলতে চান? এটি আর ফিরিয়ে আনা সম্ভব নয়।")) {
      setSessions({});
      setCurrentSessionId('');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputValue.trim() || isTyping || !isOnline) return;

    const userMessage: Message = {
      role: Role.USER,
      content: inputValue,
      timestamp: new Date()
    };

    const currentSession = sessions[currentSessionId];
    if (!currentSession) return;

    const newMessages = [...currentSession.messages, userMessage];
    
    let newTitle = currentSession.title;
    if (currentSession.title === 'নতুন চ্যাট') {
      newTitle = inputValue.length > 20 ? inputValue.substring(0, 20) + '...' : inputValue;
    }

    setSessions(prev => ({
      ...prev,
      [currentSessionId]: {
        ...prev[currentSessionId],
        messages: newMessages,
        title: newTitle,
        lastModified: new Date()
      }
    }));

    setInputValue('');
    setIsTyping(true);

    try {
      let streamedContent = '';
      for await (const chunk of geminiService.streamChat(newMessages)) {
        streamedContent += chunk;
        setSessions(prev => ({
          ...prev,
          [currentSessionId]: {
            ...prev[currentSessionId],
            messages: [
              ...newMessages,
              { role: Role.MODEL, content: streamedContent, timestamp: new Date() }
            ]
          }
        }));
      }
    } catch (error) {
      console.error(error);
    } finally {
      setIsTyping(false);
    }
  };

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages, isTyping]);

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Theme Class Mappings
  const themeClasses = {
    classic: {
      bg: 'bg-slate-50',
      main: 'bg-white/70',
      accent: 'bg-blue-600',
      accentHover: 'hover:bg-blue-700',
      text: 'text-slate-800',
      border: 'border-slate-200'
    },
    nature: {
      bg: 'bg-emerald-50',
      main: 'bg-white/80',
      accent: 'bg-emerald-600',
      accentHover: 'hover:bg-emerald-700',
      text: 'text-emerald-900',
      border: 'border-emerald-100'
    },
    night: {
      bg: 'bg-slate-950',
      main: 'bg-slate-900/60',
      accent: 'bg-indigo-500',
      accentHover: 'hover:bg-indigo-600',
      text: 'text-slate-100',
      border: 'border-slate-800'
    },
    rose: {
      bg: 'bg-rose-50',
      main: 'bg-white/80',
      accent: 'bg-rose-500',
      accentHover: 'hover:bg-rose-600',
      text: 'text-rose-900',
      border: 'border-rose-100'
    }
  };

  const currentT = themeClasses[theme];

  return (
    <div className={`flex flex-col h-screen max-w-7xl mx-auto ${currentT.bg} overflow-hidden shadow-2xl transition-colors duration-500`}>
      <Header 
        userName={user.name} 
        onNewChat={handleNewChat} 
        onDownloadAPK={handleDownloadAPK}
        isOnline={isOnline}
        theme={theme}
        onThemeChange={setTheme}
      />
      
      <div className="flex flex-1 overflow-hidden relative">
        <main className={`flex-1 flex flex-col min-w-0 ${currentT.main} backdrop-blur-sm border-r ${currentT.border} lg:border-r-0 transition-all duration-500`}>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 md:p-8 space-y-2 scroll-smooth">
            {messages.map((msg, index) => (
              <MessageItem key={index} message={msg} theme={theme} />
            ))}
            {isTyping && (
              <div className="flex justify-start mb-6">
                <div className={`${theme === 'night' ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-200'} border px-4 py-3 rounded-2xl rounded-tl-none shadow-sm flex items-center gap-1`}>
                  <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                  <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                </div>
              </div>
            )}
          </div>

          <div className={`${theme === 'night' ? 'bg-slate-900/80' : 'bg-white/80'} backdrop-blur-md border-t ${currentT.border} p-4 sticky bottom-0 transition-all duration-500`}>
            <form onSubmit={handleSubmit} className="flex gap-2 items-center max-w-4xl mx-auto">
              <div className="flex-1 relative">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  placeholder={isListening ? "শুনছি..." : "আপনার স্বাস্থ্য বিষয়ক সমস্যা লিখুন..."}
                  className={`w-full ${theme === 'night' ? 'bg-slate-800 text-white placeholder-slate-500' : 'bg-slate-100 text-slate-800'} border-none rounded-xl pl-5 pr-12 py-3 focus:ring-2 outline-none transition-all ${isListening ? 'ring-2 ring-red-400 bg-red-50' : `focus:ring-${theme === 'night' ? 'indigo' : (theme === 'nature' ? 'emerald' : (theme === 'rose' ? 'rose' : 'blue'))}-500`}`}
                  disabled={isTyping || !isOnline}
                />
                <button type="button" onClick={toggleVoiceInput} className={`absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg transition-colors ${isListening ? 'text-red-600 animate-pulse' : 'text-slate-400 hover:text-blue-600'}`}>
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                </button>
              </div>
              <button 
                type="submit" 
                disabled={!inputValue.trim() || isTyping || !isOnline} 
                className={`${currentT.accent} ${currentT.accentHover} text-white p-3 rounded-xl disabled:bg-slate-300 transition-all shadow-md active:scale-95`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
              </button>
            </form>
          </div>
        </main>

        <Sidebar 
          theme={theme}
          sessions={Object.values(sessions).sort((a, b) => b.lastModified.getTime() - a.lastModified.getTime())}
          currentSessionId={currentSessionId}
          onSwitchSession={setCurrentSessionId}
          onDeleteSession={handleDeleteSession}
          onClearAll={handleClearAllHistory}
          onNewChat={handleNewChat}
          onDownloadAPK={handleDownloadAPK}
        />
      </div>
    </div>
  );
};

export default App;
